<?php 
	
	header('Location: login_form.php');
	exit;

 ?>